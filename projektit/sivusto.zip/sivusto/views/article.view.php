<?php require "partials/head.php"; ?>

<h2 class="centered">Lue uutiset</h2>

<div class="article">
    <div class="articleheader"></div>
    <div class="articlebody"></div>
    <div class="articlefooter"></div>
</div>

<?php require "partials/footer.php"; ?>