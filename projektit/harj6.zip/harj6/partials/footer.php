<footer class="centeredtext"></footer>
</body>
</html>