<footer class="centeredtext">© 2024, Noel Kivelä</footer>
</body>
</html>
